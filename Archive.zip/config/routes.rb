Rails.application.routes.draw do

  devise_for :users

  #root 'home#index'
  get 'home/private'
  get 'pages/home'
  root 'pages#index'
  get 'account_edition' => 'pages#compte'
  get 'publications' => 'pages#publications'
  get 'messagerie' => 'pages#messagerie'
  get 'newmessage' => 'pages#newmessage'
  post 'newmessage' => 'pages#postmessage'
  get 'message/:id' => 'pages#show'
  patch 'account_edition' => 'pages#update'

  get 'publications' => 'pages#publications'
  post 'publications' => "pages#create"
  delete 'publications' => 'pages#destroy'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

end
