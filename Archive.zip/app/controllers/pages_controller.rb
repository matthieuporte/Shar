class PagesController < ApplicationController

	def messagerie
		@allMessages = Message.where(id_destinataire: current_user.id).reverse
	end

	def newmessage
	end

	def postmessage
		@allMessages = Message.all

		path = 0

		if(User.where(username: params[:dest]).ids.first == nil)
			redirect_to '/newmessage'
			path = 1
		else
			if (path == 0)
				id_dest = User.where(username: params[:dest]).ids.first
				contenu = params[:message]
				id_auteur = current_user.id
				Message.create id_auteur: id_auteur, id_destinataire: id_dest, contenu: contenu, date: Time.now
				redirect_to '/messagerie'
			end
		end
	end

	def show
		@activeMessage = Message.find(params[:id])
	end

	def compte
		@user = User.find(current_user.id)
	end

	def publications
	    @allPublications = Publication.where(auteur_id: current_user.id).reverse
    end
    def create
    	Publication.create auteur_id: current_user.id, auteur: current_user.username, titre: params[:titre], contenu: params[:contenu], date: Time.now, likes: 0
    	redirect_to "/publications"
    end
    def destroy
    	@publication_actuelle = Publication.find(params[:id_publication])
    	@publication_actuelle.destroy
    	redirect_to "/publications"
    end
    def index
    	@allPublications = Publication.all.reverse
    	@countRecents = 0;
    end
end
